
"use strict";

let DistanceToFlag = require('./DistanceToFlag.js')

module.exports = {
  DistanceToFlag: DistanceToFlag,
};
